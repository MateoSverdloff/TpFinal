import DBConfig from '../configs/dbConfig.js';
import pkg from 'pg'
const { Client, Pool }  = pkg;

export default class EventRepository {
    getAllAsync = async () => {
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
await client.connect();
            const sql = `SELECT * FROM event_categories`;
            const result = await client.query(sql);
await client.end();
            returnArray = result.rows;
        } catch (error) {
            console.log(error);
        }
        return returnArray;
    }

    getByIdAsync = async (id) => {
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
        await client.connect();
                    const sql = `SELECT * FROM event_categories Where id = $1`;
                    const values = [id];  // [2, 'mate´´]
                    const result = await client.query(sql, values);
        await client.end();
                    returnArray = result.rows;
                } catch (error) {
                    console.log(error);
                }
        return returnArray;
    }

    createAsync = async (entity) => {
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
        await client.connect();
                    const sql = `Insert Into event_categories (name, display_order) Values ($1, $2) WHERE name!=null`;
                    const values = [entity.name,entity.display_order];  // [2, 'mate´´]
                    const result = await client.query(sql, values);
        await client.end();
                    returnArray = result.rows;
                } catch (error) {
                    console.log(error);
                }
        return returnArray;
    }

    updateAsync = async (entity) => {
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
        await client.connect();
        //ERROR CERCA DE PUT
                    const sql = `Put Into event_categories (name, display_order) Values ($1, $2)`;
                    const values = [entity.name, entity.display_order];  // [2, 'mate´´]
                    const result = await client.query(sql, values);
        await client.end();
                    returnArray = result.rows;
                } catch (error) {
                    console.log(error);
                }
        return returnArray;
    }
    deleteByIdAsync = async (id) => {
        //ERROR NO PUEDE HACER DELETE
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
        await client.connect();
                    const sql = `DELETE * FROM event_categories Where id = $1`;
                    const values = [id];  // [2, 'mate´´]
                    const result = await client.query(sql, values);
        await client.end();
                    returnArray = result.rows;
                } catch (error) {
                    console.log(error);
                }
        return returnArray;
}

}
