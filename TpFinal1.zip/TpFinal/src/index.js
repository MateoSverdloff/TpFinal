import express from "express";
import cors    from "cors";
import CategorieRouter from "./controllers/categorie-controller.js"
import UserRouter from "./controllers/user-controller.js"
//...
const app  = express();
const port = 3000;
//...
// Inclusión de los Middlewares
app.use(cors());
app.use(express.json());
app.use('/api/categories', CategorieRouter);
app.use('/api/users', UserRouter);
app.listen(port, () => {
  console.log(`"server" Listening on port ${port}`);
})