import DBConfig from '../configs/dbConfig.js';
import pkg from 'pg'
const { Client, Pool }  = pkg;

export default class LocationsRepository {
    getAllAsync = async (nombreTalba) => {
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
await client.connect();
            const sql = `SELECT * FROM event_locations`;
            const result = await client.query(sql);
await client.end();
            returnArray = result.rows;
        } catch (error) {
            console.log(error);
        }
        return returnArray;
    }

    getByIdAsync = async (id) => {
        let returnLocation = null;
        const client = new Client(DBConfig);
        try {
            await client.connect();
            const sql = `SELECT * FROM event_locations Where id = $1`;
            const values = [id];  // [2, 'mate´´]
            const result = await client.query(sql, values);
            await client.end();
            if (result.rows.length > 0){
                returnEntity = result.rows[0];
            }
            
        } catch (error) {
            console.log(error);
        }
        return returnEntity;
    }

    createAsync = async (entity) => {
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
        await client.connect();
                    const sql = `Insert Into event_locations (id_location=$1,name=$2,full_address=$3,max_capacity=$4,latitude=$5,longitude=$6,id_creator_user=$7) Values ($1, $2, $3, $4, $5, $6, $7)`;
                    const values = [entity.id_location, entity.name, entity.full_address, entity.max_capacity, entity.latitude, entity.longitude, entity.id_creator_user];  // [2, 'mate´´]
                    const result = await client.query(sql, values);
        await client.end();
                    returnArray = result.rows;
                } catch (error) {
                    console.log(error);
                }
        return returnArray;
    }

    //falta acaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa

    updateAsync = async (entity) => {
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
        await client.connect();
        //ERROR CERCA DE PUT
                    const sql = `update public.event_locations SET id_location=$1,name=$2,full_address=$3,max_capacity=$4,latitude=$5,longitude=$6,id_creator_user=$7 WHERE id = $8 `;
                    const values = [entity.id_location, entity.name, entity.full_address, entity.max_capacity, entity.latitude, entity.longitude, entity.id_creator_user];  
                    const result = await client.query(sql, values);
        await client.end();
                    returnArray = result.rows;
                } catch (error) {
                    console.log(error);
                }
        return returnArray;
    }
    deleteByIdAsync = async (id) => {
        console.log('id: ',id)
        //ERROR NO PUEDE HACER DELETE
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
        await client.connect();
                    const sql = `DELETE FROM event_locations Where id = $1`;
                    const values = [id];
                    
                    const result = await client.query(sql, values);
        await client.end();
                    returnArray = result.rows;
                } catch (error) {
                    console.log(error);
                }
        return returnArray;
}

}
