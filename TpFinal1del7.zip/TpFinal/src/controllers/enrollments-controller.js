import {Router} from 'express';
import EventService from './../services/enrollments-services.js';
import authMiddleware from '../middlewares/auth-middleware.js';
import EnrollmentService from './../services/enrollments-services.js';
const router = Router();
const svc    = new EnrollmentService();

router.post('/:id/enrollment', authMiddleware, async (req, res, next) => { // no entra aca, ayuda
    console.log("entro al param xxxxxxx")
    let respuesta;
    let id_evento = req.params.id;
    let id_user = req.user.id;
    console.log('req.user', req.user);
    const returnArray = await svc.updateAsync(id_user);
    if (returnArray != null){
      respuesta = res.status(200).json(returnArray);
    } else {
      respuesta = res.status(500).send(`Error interno.`);
    }
    return respuesta;
  });

  export default router;