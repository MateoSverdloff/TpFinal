import {Router} from 'express';
import EventService from './../services/event-services.js';
import authMiddleware from '../middlewares/auth-middleware.js';
//import objRespuesta from './event-controller.js'
const router = Router();
const svc    = new EventService();


router.get('', async (req, res) => {
    let respuesta;

    let name = req.query.name;
    let tag = req.query.tag;
    let description = req.query.description;
    let id_creator_user = req.query.id_creator_user;
    let id_event_category = req.query.id_event_category;
    let id_event_location = req.query.id_event_location;
    let duration_in_minutes = req.query.duration_in_minutes;
    let price = req.query.price;
    let enabled_for_enrollment = req.query.enabled_for_enrollment;
    let max_assistance = req.query.max_assistance;
    let start_date = req.query.start_date;

    const returnArray = await svc.getAllAsync(name, tag, description, id_event_category, id_event_location, start_date, duration_in_minutes, price, enabled_for_enrollment, max_assistance, id_creator_user);
    if (returnArray != null){
      respuesta = res.status(200).json(returnArray);
    } else {
      respuesta = res.status(500).send(`Error interno.`);
    }
    return respuesta;
  });


  router.get('/:id', async (req, res) => {
    let respuesta;
    let id = req.params.id;
    console.log(id)
    const returnArray = await svc.getByIdAsync(id);
    if (returnArray != null){
      respuesta = res.status(200).json(returnArray);
    } else {
      respuesta = res.status(500).send(`Error interno.`);
    }
    return respuesta;
   });
   /*
   router.post('/:id/enrollment', authMiddleware, async (req, res, next) => { 
    console.log("entro al param")
    let respuesta;
    let id_evento = req.params.id;
    let id_user = req.user.id;
    console.log('los id 1  son: ', id_evento, id_user)

    const returnArray = await svc.updateAsync(id_user, id_evento);
    if (returnArray != null){
      respuesta = res.status(200).json(returnArray);
    } else {
      respuesta = res.status(500).send(`Error interno.`);
    }
    return respuesta;
  });
  */


  export default router;