import DBConfig from '../configs/dbConfig.js';
import pkg from 'pg'
const { Client, Pool }  = pkg;

export default class EventRepository {
    updateAsync = async (id_evento, id_user) => {
        let rowCount = 0;
        const client = new Client(DBConfig);
        try {
            console.log('los id 2 son:  ', id_evento, id_user)
        await client.connect();
                    const sql = `update public.event_enrollments SET id_event=$1, id_user = $2`; 
                    rowCount++;
                    const values = [id_evento, id_user]; 
                    const result = await client.query(sql, values);
        await client.end();
             rowCount = result.rowCount;
                } catch (error) {
                    console.log(error);
                }
        return rowCount;
        }
    }
/*
export default class EventRepository {
    getAllAsync = async (nombreTalba) => {
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
await client.connect();
            const sql = `SELECT * FROM event_enrollments`;
            const result = await client.query(sql);
await client.end();
            returnArray = result.rows;
        } catch (error) {
            console.log(error);
        }
        return returnArray;
    }

    getByIdAsync = async (id) => {
        let returnEntity = null;
        const client = new Client(DBConfig);
        try {
            await client.connect();
            const sql = `SELECT * FROM event_enrollments Where id = $1`;
            const values = [id];  // [2, 'mate´´]
            const result = await client.query(sql, values);
            await client.end();
            if (result.rows.length > 0){
                returnEntity = result.rows[0];
            }
            
        } catch (error) {
            console.log(error);
        }
        return returnEntity; 
    }

    createAsync = async (entity) => {
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
        await client.connect();
                    const sql = `Insert Into event_enrollments (id_event=$1, id_user=$2, registration_data_time=$3, attended=$4, observation=$5, rating=$6) Values ($1, $2, $3, $4, $5, $6)`;
                    const values = [entity.id_event,];  // [2, 'mate´´]
                    const result = await client.query(sql, values);
        await client.end();
                    returnArray = result.rows;
                } catch (error) {
                    console.log(error);
                }
        return returnArray;
    }

    updateAsync = async (entity) => {
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
        await client.connect();
        //ERROR CERCA DE PUT
                    const sql = `update public.event_enrollments SET name = $2, display_order = $3 WHERE id = $1 `;
                    const values = [entity.id, entity.name, entity.display_order];  
                    const result = await client.query(sql, values);
        await client.end();
                    returnArray = result.rows;
                } catch (error) {
                    console.log(error);
                }
        return returnArray;
    }
    deleteByIdAsync = async (id) => {
        console.log('id: ',id)
        //ERROR NO PUEDE HACER DELETE
        let returnArray = null;
        const client = new Client(DBConfig);
        try {
        await client.connect();
                    const sql = `DELETE FROM event_enrollments Where id = $1`;
                    const values = [id];
                    
                    const result = await client.query(sql, values);
        await client.end();
                    returnArray = result.rows;
                } catch (error) {
                    console.log(error);
                }
        return returnArray;
}

}

*/