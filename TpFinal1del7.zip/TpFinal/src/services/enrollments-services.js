import EnrollmentsRepository from '../repositories/enrollments-respoitory.js';

export default class EnrollmentService {
  getAllAsync = async () => {
    const repo = new EnrollmentsRepository();
    const returnArray = await repo.getAllAsync();
    return returnArray;
  }

  getByIdAsync = async (id) => {
    const repo = new EnrollmentsRepository();
    const returnArray = await repo.getByIdAsync(id);
    return returnArray;
  }

  createAsync = async (id_evento, id_user) => {
    const repo = new EnrollmentsRepository();
    const returnArray = await repo.createAsync(id_evento, id_user);
    return returnArray;
  }

  updateAsync = async (id_evento) => {
    const repo = new EnrollmentsRepository();
    const returnArray = await repo.updateAsync(id_evento);
    return returnArray;
  }
  
  deleteByIdAsync = async (id) => {
    const repo = new EnrollmentsRepository();
    const returnArray = await repo.deleteByIdAsync(id);
    return returnArray;
  }

}
