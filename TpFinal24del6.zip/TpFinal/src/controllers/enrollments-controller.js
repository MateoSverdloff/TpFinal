router.post('', async (req, res) => {
    let respuesta;
    let entity = req.body;
    const returnArray = await svc.createAsync(entity);
    if (returnArray != null){
      respuesta = res.status(200).json(returnArray);
    } else {
      respuesta = res.status(500).send(`Error interno.`);
    }
    return respuesta;
  });