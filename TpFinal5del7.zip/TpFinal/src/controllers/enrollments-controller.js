import { Router } from 'express';
import EnrollmentService from './../services/enrollments-services.js';
import authMiddleware from '../middlewares/auth-middleware.js';

const router = Router();
const svc = new EnrollmentService();

router.put('/:id/enrollment', authMiddleware, async (req, res, next) => {
    let respuesta;
    let id_evento = req.params.id;
    let id_user = req.user.id;
    try {
        const returnArray = await svc.createAsync(id_user, id_evento);
        if (returnArray != null) {
            respuesta = res.status(200).json(returnArray);
        } else {
            respuesta = res.status(500).send(`Error interno.`);
        }
    } catch (error) {
        console.error(error);
        respuesta = res.status(500).send(`Error interno.`);
    }
    return respuesta;
});

router.delete('/:id/enrollment', authMiddleware, async (req, res, next) => {
  let respuesta;
  let id_user = req.user.id;
  console.log('user:', id_user)
  try {
      const returnArray = await svc.deleteByIdAsync(id_user);
      if (returnArray != null) {
          respuesta = res.status(200).json(returnArray);
      } else {
          respuesta = res.status(500).send(`Error interno.`);
      }
  } catch (error) {
      console.error(error);
      respuesta = res.status(500).send(`Error interno.`);
  }
  return respuesta;
});

router.patch('/:id/enrollment/:rating', authMiddleware, async (req, res, next) => {
  let respuesta;
  let id_event = req.params.id;
  let rating = req.params.rating;
  console.log('id evetno y rating:', id_event, rating)
  try {
      const returnArray = await svc.patchByIdAsync(id_event, rating);
      if (returnArray != null) {
          respuesta = res.status(200).json(returnArray);
      } else {
          respuesta = res.status(500).send(`Error interno.`);
      }
  } catch (error) {
      console.error(error);
      respuesta = res.status(500).send(`Error interno.`);
  }
  return respuesta;
});


export default router;
